function changeFields(){
  const type=document.getElementById("type").value;
  const fields=document.getElementById("fields");
  fields.style.display = type==="Other Legal Document" ? "none" : "block";
}