# Legal Ease – AI-Powered Legal Document Generator

This starter project follows the workflow described in the presentation:
Login → Select document type → Enter details → Generate → Review/Edit → Download → History.

## Run
1. Install Python 3.
2. Open terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `python app.py`
5. Open: `http://127.0.0.1:5000`

## Notes
- SQLite database is created automatically as `legal_ease.db`.
- The generator is a simple demo/template engine, not a legal-advice system.
- The PPT mentions AI generation and PDF output; this starter version uses rule-based document generation and a text download so it can run with minimal dependencies.
- A production version can connect an approved AI API and add a PDF library such as ReportLab.
